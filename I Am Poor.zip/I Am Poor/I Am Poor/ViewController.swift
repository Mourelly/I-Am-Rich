//
//  ViewController.swift
//  I Am Poor
//
//  Created by Yaroslav on 04.01.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

